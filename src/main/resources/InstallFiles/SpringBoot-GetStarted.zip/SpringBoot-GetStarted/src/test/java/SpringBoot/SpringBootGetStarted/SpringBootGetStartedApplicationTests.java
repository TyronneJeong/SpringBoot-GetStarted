package SpringBoot.SpringBootGetStarted;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootGetStartedApplicationTests {

	@Test
	void contextLoads() {
	}

}
