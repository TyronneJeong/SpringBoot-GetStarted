package SpringBoot.SpringBootGetStarted;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootGetStartedApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootGetStartedApplication.class, args);
	}

}
